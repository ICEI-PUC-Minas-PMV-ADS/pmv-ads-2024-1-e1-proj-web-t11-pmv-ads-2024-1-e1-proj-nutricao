<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>Página Inicial - Nutricão</title>
</head>

<body>
    
<header>
    <div class="div-topo">
        <div class="logo">
            <img src="imagens/logo.png" alt="">
            </div>
            <div class="lista-topo">
                <ul>
                    <li>Item</li>
                    <li>Item</li>
                    <li>Item</li>
                    <li>Item</li>
                </ul>
        </div>
    </div>
</header>

    <main>

    <div class="div-banner">
<div class="img-banner"><img src="" alt=""></div>
<div class="banner-carne"></div>
    <div class="banner-cenoura"></div>
    <div class="banner-abobora"></div>
    <div class="btn-banner" ><a href="#">Saiba mais</a></div>
</div>


        <div class="div-cards-index">

            <div class="cards-index">
                <img src="imagens/icones/icone1.png" alt="">
                <div>
                    <h2>Lorem ipsum dolor</h2>
                    <p>sit amet consectetur adipisicing elit. Aliquam nulla numquam dolore distinctio.</p>
                </div>
            </div>

            <div class="cards-index">
                <img src="imagens/icones/icone2.png" alt="">
                <div>
                    <h2>Lorem ipsum dolor</h2>
                    <p>sit amet consectetur adipisicing elit. Aliquam nulla numquam dolore distinctio.</p>
                </div>
            </div>

            <div class="cards-index">
                <img src="imagens/icones/icone3.png" alt="">
                <div>
                    <h2>Lorem ipsum dolor</h2>
                    <p>sit amet consectetur adipisicing elit. Aliquam nulla numquam dolore distinctio.</p>
                </div>
            </div>

        </div>

        <div class="sobre-nos">
            <div class="sobre-nos-img">
                <img src="imagens/sobre-nos.png" alt="">
            </div>
            <div class="sobre-nos-txt">
                <h2>The Best for Your Pet!</h2>
                <div>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.</p>
                    <p>Eam ad sale persius, id vis iudicabit cor rumpit. Usu ad modo illum assum.</p>
</div>

                <ul>
                    <li>Lorem ipsum dolor sit amet, consectetur</li>
                    <li>No delenit detracto eum, vix ne integre taci</li>
                    <li>An pro facete dicuntei ut epicuri</li>
                </ul>
            </div>
        </div>

        <div class="parallax">
            <div class="parallax-texto">
            <div>
                <h2>Want a pet for <br> your loved ones?</h2>
                <p>Elit sanctus mea no. Ne duo vocent vocibus consetetur. Singulis etam pericula an vis, pri graeco partiendo te, alii admodum copiosae id sea. Per no malis liber fierent.</p>
            </div>
            </div>
        </div>


        <div class="cards-index2-fora">
            <div class="cards-index2" id="card1">
                <div><img src="imagens/card1.jpg" alt=""></div>
                <div class="cards-index2-txt"><h3>lorem ipsum</h3>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis vitae, rerum expedita illo aliquid sed quod laboriosam fugit dolores nemo consectetur.</p></div>
                <div class="cards-index2-bttn">
                   <div></div>
                </div>
            </div>
            <div class="cards-index2" id="card2">
                <div><img src="imagens/card2.jpg" alt=""></div>
                <div class="cards-index2-txt"><h3>lorem ipsum</h3>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis vitae, rerum expedita illo aliquid sed quod laboriosam fugit dolores nemo consectetur.</p></div>
                    <div class="cards-index2-bttn">
                   <div></div>
                </div>
            </div>
            <div class="cards-index2" id="card3">
                <div><img src="imagens/card3.jpg" alt=""></div>
                <div class="cards-index2-txt"><h3>lorem ipsum</h3>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis vitae, rerum expedita illo aliquid sed quod laboriosam fugit dolores nemo consectetur.</p></div>
                    <div class="cards-index2-bttn">
                   <div></div>
                </div>
            </div>
            </div>

            <div class="div-cards-contador">

            <div class="cards-contador-fora">
                <div class="cards-contador">
                    <img src="imagens/icones/icone1.png" alt="">
                    <div class="contador">
                       0
                    </div>
                </div>
                <div class="p-contador">lorem ipsum</div>
            </div>

            <div class="cards-contador-fora">
                <div class="cards-contador">
                    <img src="imagens/icones/icone2.png" alt="">
                    <div class="contador">
                       0
                    </div>
                </div>
                <div class="p-contador">lorem ipsum</div>
            </div>

            <div class="cards-contador-fora">
                <div class="cards-contador">
                    <img src="imagens/icones/icone3.png" alt="">
                    <div class="contador">
                       0
                    </div>
                </div>
                <div class="p-contador">lorem ipsum</div>
            </div>
            

        </div>


        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/1.17.0/TweenMax.min.js"></script>
    <script>
        
 // Função para contar de 0 a 100 com uma animação
function count(){
  // Objeto counter usado para armazenar o valor do contador
  var contador = { var: 0 };

  // Utilizando a biblioteca TweenMax para animar o contador
  TweenMax.to(contador, 3, {
    // Definindo o valor final do contador como 100
    var: 1725, 
    
    // Função chamada a cada atualização do valor do contador
    onUpdate: function () {
      // Arredonda o valor do contador para o inteiro mais próximo
      var number = Math.ceil(contador.var);
      
      // Atualiza o conteúdo do elemento HTML com a classe 'contador' com o valor arredondado do contador
      $('.contador').html(number);
      
      // Verifica se o número arredondado é igual ao valor atual do contador
      if(number === contador.var){ 
        // Se sim, encerra a animação
        count.kill(); 
      }
    },
    
    // Função chamada quando a animação é concluída
    onComplete: function(){
      // Reinicia a contagem
      count();
    },    
    
    // Define a função de animação para acelerar e desacelerar com o tempo
    ease:Circ.easeOut
  });
}

// Inicia a contagem
count();
    </script>
    </main>
   
    <footer>
    <div class="div-rodape"></div>
</footer>
    
</body>

</html>